package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AddReviewActivity extends AppCompatActivity {

    private RatingBar itemRating;
    private EditText itemRemarksInput;
    private DatabaseReference mDatabase;
    private String selectedCategory;
    private String itemId;
    private CheckBox shareLocationCheckbox;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        selectedCategory = getIntent().getStringExtra("SELECTED_CATEGORY");
        itemId = getIntent().getStringExtra("SELECTED_ITEM");
        itemRating = findViewById(R.id.item_rating);
        itemRemarksInput = findViewById(R.id.item_remarks_input);
        shareLocationCheckbox = findViewById(R.id.my_checkbox);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        findViewById(R.id.post_button).setOnClickListener(v -> postReview());
    }

    private void postReview() {
        String userId = getCurrentUserName();
        float rating = itemRating.getRating();
        String remarks = itemRemarksInput.getText().toString();
        Map<String, Object> review = new HashMap<>();
        review.put("userId", userId);
        review.put("rating", rating);
        review.put("remarks", remarks);

        if (shareLocationCheckbox.isChecked()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return;
            }
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                review.put("latitude", location.getLatitude());
                review.put("longitude", location.getLongitude());
            } else {
                Toast.makeText(this, "Failed to get location", Toast.LENGTH_SHORT).show();
            }
        }

        mDatabase.child("categories").child(selectedCategory).child("items").child(itemId).child("reviews").push().setValue(review)
                .addOnSuccessListener(aVoid -> Toast.makeText(AddReviewActivity.this, "Review posted successfully", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(AddReviewActivity.this, "Failed to post review", Toast.LENGTH_SHORT).show());

        finish();
    }

    private String getCurrentUserName() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        return (currentUser != null) ? currentUser.getDisplayName() : null;
    }
}
