package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

public class ItemActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private TextView categoryTitleTextView;
    private FloatingActionButton addItemButton;
    private ListView listView;
    private ArrayList<String> itemList;
    private ArrayAdapter<String> adapter;
    private static final int ADD_ITEM_REQUEST = 1;
    private String selectedCategory;

    public class Item {
        private String name;

        private Map<String, Object> Items; // Or use a more specific class instead of Object


        public Item() {
            // Default constructor needed for Firebase
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        categoryTitleTextView = findViewById(R.id.category_title_text_view);
        addItemButton = findViewById(R.id.add_item_button);
        listView = findViewById(R.id.listView);

        selectedCategory = getIntent().getStringExtra("SELECTED_CATEGORY");
        categoryTitleTextView.setText(selectedCategory);

        itemList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(adapter);

        loadItemsFromFirebase();

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ItemActivity.this, AddItemActivity.class);
                intent.putExtra("SELECTED_CATEGORY", selectedCategory);
                startActivityForResult(intent, ADD_ITEM_REQUEST);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = itemList.get(position);
                Intent intent = new Intent(ItemActivity.this, ReviewActivity.class);
                intent.putExtra("SELECTED_ITEM", selectedItem);
                intent.putExtra("SELECTED_CATEGORY", selectedCategory);
                startActivity(intent);
            }
        });
    }

    private void loadItemsFromFirebase() {
        mDatabase.child("categories").child(selectedCategory).child("items")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        itemList.clear();
                        for (DataSnapshot itemSnapshot : dataSnapshot.getChildren()) {
                            Object value = itemSnapshot.getValue();
                            if (value instanceof String) {
                                // If the value is just a string, add it directly
                                itemList.add((String) value);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(ItemActivity.this, "Failed to load items.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST && resultCode == RESULT_OK) {
            // Refresh the list of items
            loadItemsFromFirebase();
        }
    }

    public void logout_user(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(this, StartActivity.class));
        Toast.makeText(this, "Logged out", Toast.LENGTH_LONG).show();
        finish();
    }
}
