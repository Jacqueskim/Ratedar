package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

public class UserActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private TextView userNameTextView;
    private FloatingActionButton addCategoryButton;
    private ListView listView;
    private ArrayList<String> categoryList;
    private ArrayAdapter<String> adapter;

    public class Category {
        private String name;
        private Map<String, Object> Categorys; // Or use a more specific class instead of Object

        public Category() {
            // Default constructor needed for Firebase
        }

        // Getter for the 'name' field
        public String getName() {
            return name;
        }

        // Setter for the 'name' field
        public void setName(String name) {
            this.name = name;
        }
        // Getters and setters
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        // Initialize Firebase Database reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        userNameTextView = findViewById(R.id.category_title_text_view);
        addCategoryButton = findViewById(R.id.add_category_button);
        listView = findViewById(R.id.listView);

        // get username from LoginActivity
        String userEmail = getIntent().getStringExtra("USER_EMAIL");
        userNameTextView.setText(userEmail); // Set the user name to TextView

        // Initialize category list and adapter
        categoryList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categoryList);
        listView.setAdapter(adapter);

        mDatabase.child("categories").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                categoryList.clear();
                for (DataSnapshot categorySnapshot : dataSnapshot.getChildren()) {
                    Object value = categorySnapshot.getValue();
                    if (value instanceof String) {
                        // If the value is just a string, add it directly
                        categoryList.add((String) value);
                    }
                    // Add more conditions if your data can be in other formats
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(UserActivity.this, "Failed to load categories.", Toast.LENGTH_SHORT).show();
            }
        });



        addCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewCategory();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(UserActivity.this, ItemActivity.class);
                intent.putExtra("USER_NAME", userNameTextView.getText().toString());
                intent.putExtra("SELECTED_CATEGORY", categoryList.get(position));
                startActivity(intent);
            }
        });

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                .setDisplayName(userNameTextView.getText().toString())
                .build();

        user.updateProfile(profileUpdates)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d("UserName", "User profile updated.");
                    }
                });

    }

    private void addNewCategory() {
        Intent intent = new Intent(UserActivity.this, AddCategoryActivity.class);
        startActivity(intent);
    }

    public void logout_user(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(this, StartActivity.class));
        Toast.makeText(this, "Logged out", Toast.LENGTH_LONG).show();
        finish();
    }
}
