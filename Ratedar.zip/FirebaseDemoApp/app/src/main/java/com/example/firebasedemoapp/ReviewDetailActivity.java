package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.RatingBar;

public class ReviewDetailActivity extends AppCompatActivity {

    private TextView userNameTextView;
    private RatingBar reviewRatingBar;
    private TextView reviewRemarksTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_detail);

        userNameTextView = findViewById(R.id.category_title_text_view);
        reviewRatingBar = findViewById(R.id.review_rating_bar);
        reviewRemarksTextView = findViewById(R.id.review_remarks_text_view);

        // Get the review details passed from ReviewActivity
        String userName = getIntent().getStringExtra("USER_NAME");
        float rating = getIntent().getFloatExtra("RATING", 0);
        String remarks = getIntent().getStringExtra("REMARKS");

        // Set the review details
        userNameTextView.setText(userName);
        reviewRatingBar.setRating(rating);
        reviewRemarksTextView.setText(remarks);
    }
}
