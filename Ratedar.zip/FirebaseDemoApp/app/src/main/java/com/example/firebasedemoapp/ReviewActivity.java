package com.example.firebasedemoapp;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import androidx.core.app.ActivityCompat;

public class ReviewActivity extends AppCompatActivity implements LocationListener {

    private TextView reviewTitleTextView;
    private FloatingActionButton addReviewButton;
    private ArrayList<String> reviewList;
    private ArrayAdapter<String> adapter;
    private ListView listView;
    private static final int ADD_REVIEW_REQUEST = 2;
    private DatabaseReference mDatabase;
    private String selectedItem;

    private Location currentUserLocation; // You need to set this value from the actual user location

    private LocationManager locationManager;
    private ArrayList<Review> reviewObjects = new ArrayList<>();

    // Review class to map the data structure
    public static class Review {
        public String userId;
        public String remarks;
        public double rating;
        public Double latitude;
        public Double longitude;

        public Review() {
            // Default constructor required for calls to DataSnapshot.getValue(Review.class)
        }

        public String getUserId() {
            return userId;
        }

        public String getRemarks() {
            return remarks;
        }

        public double getRating() {
            return rating;
        }

        public Double getLatitude() {
            return latitude;
        }

        public Double getLongitude() {
            return longitude;
        }

        // Additional method in the Review class to check if location data exists
        public boolean hasLocation() {
            return latitude != null && longitude != null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        // Initialize LocationManager
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Get the current location
        getCurrentLocation();

        mDatabase = FirebaseDatabase.getInstance().getReference();
        reviewTitleTextView = findViewById(R.id.review_title_text_view);
        addReviewButton = findViewById(R.id.add_review_button);
        listView = findViewById(R.id.review_listView);

        selectedItem = getIntent().getStringExtra("SELECTED_ITEM");
        reviewTitleTextView.setText(selectedItem);

        reviewList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, reviewList);
        listView.setAdapter(adapter);

        loadReviewsFromFirebase();

        addReviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReviewActivity.this, AddReviewActivity.class);
                intent.putExtra("SELECTED_CATEGORY", "Food"); // Replace with actual category
                intent.putExtra("SELECTED_ITEM", selectedItem);
                startActivityForResult(intent, ADD_REVIEW_REQUEST);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 从reviewList获取被点击的评论文本
                String selectedReview = reviewList.get(position);

                // 解析出评论的各个部分
                String[] parts = selectedReview.split(", ");
                String userName = parts[0].split(": ")[1]; // "User: userName" 中的 userName
                float rating = Float.parseFloat(parts[1].split(": ")[1]); // "Rating: ratingValue" 中的 ratingValue
                String remarks = parts[2].split(": ")[1]; // "Remarks: remarksText" 中的 remarksText

                // 创建Intent并启动ReviewDetailActivity
                Intent intent = new Intent(ReviewActivity.this, ReviewDetailActivity.class);
                intent.putExtra("USER_NAME", userName);
                intent.putExtra("RATING", rating);
                intent.putExtra("REMARKS", remarks);
                startActivity(intent);
            }
        });




    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, this, null);
    }

    @Override
    public void onLocationChanged(Location location) {
        currentUserLocation = location;
        loadReviewsFromFirebase();
    }

    private void loadReviewsFromFirebase() {
        mDatabase.child("categories").child("Food").child("items")
                .child(selectedItem).child("reviews")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        reviewList.clear();
                        for (DataSnapshot reviewSnapshot : dataSnapshot.getChildren()) {
                            Review review = reviewSnapshot.getValue(Review.class);
                            String reviewDisplay = formatReviewString(review);
                            reviewList.add(reviewDisplay);
                        }
                        adapter.notifyDataSetChanged();
                    }

                    private String formatReviewString(Review review) {
                        String displayText = "User: " + review.getUserId() +
                                ", Rating: " + review.getRating() + ", Remarks: " + review.getRemarks();
                        if (currentUserLocation != null && review.hasLocation()) {
                            Log.d("position","calculate distance");
                            float distance = calculateDistance(
                                    review.getLatitude(),
                                    review.getLongitude(),
                                    currentUserLocation.getLatitude(),
                                    currentUserLocation.getLongitude()
                            );
                            displayText += ", Distance: " + distance + " km";
                        }
                        return displayText;
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(ReviewActivity.this, "Failed to load reviews.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_REVIEW_REQUEST && resultCode == RESULT_OK) {
            // Refresh reviews after a new one is added
            loadReviewsFromFirebase();
        }
    }

    private float calculateDistance(double startLatitude, double startLongitude, double endLatitude, double endLongitude) {
        float[] results = new float[1];
        Location.distanceBetween(startLatitude, startLongitude, endLatitude, endLongitude, results);
        return results[0] / 1000; // Convert meters to kilometers
    }

    public void logout_user(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(this, StartActivity.class));
        Toast.makeText(this, "Logged out", Toast.LENGTH_LONG).show();
        finish();
    }
}
