package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddItemActivity extends AppCompatActivity {

    private EditText itemNameEditText;
    private DatabaseReference mDatabase;
    private String selectedCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item); // Ensure this layout has itemNameEditText

        // Initialize Firebase Database reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Make sure that the intent has the extra "SELECTED_CATEGORY"
        selectedCategory = getIntent().getStringExtra("SELECTED_CATEGORY");
        if (selectedCategory == null) {
            Toast.makeText(this, "Error: No category selected.", Toast.LENGTH_LONG).show();
            finish(); // Close the activity if no category is selected
            return;
        }

        itemNameEditText = findViewById(R.id.itemNameEditText);
        TextView navBarTitle = findViewById(R.id.navBarTitle);
        navBarTitle.setText("Add Item"); // Set the title for the activity
    }

    public void finishAddingItem(View view) {
        String itemName = itemNameEditText.getText().toString();
        if (!itemName.isEmpty()) {
            // Write the new item to Firebase under the selected category
            mDatabase.child("categories").child(selectedCategory).child("items").push().setValue(itemName);
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
        } else {
            Toast.makeText(this, "Please enter an item name", Toast.LENGTH_SHORT).show();
        }
    }
}
