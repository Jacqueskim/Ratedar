package com.example.firebasedemoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddCategoryActivity extends AppCompatActivity {

    private EditText categoryNameEditText;
    private DatabaseReference mDatabase; // Firebase database reference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);

        // Initialize Firebase Database reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        categoryNameEditText = findViewById(R.id.categoryNameEditText);
        TextView navBarTitle = findViewById(R.id.navBarTitle);
        navBarTitle.setText("Adding New Category");
    }

    public void finishAddingCategory(View view) {
        String categoryName = categoryNameEditText.getText().toString();
        if (!categoryName.isEmpty()) {
            // Write the new category to Firebase
            mDatabase.child("categories").push().setValue(categoryName);
            Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show();
            finish(); // Close activity after adding
        } else {
            Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show();
        }
    }
}
